<!-- MULTI-SPECIALS SLIDER -->
<div id="multi-slider" class="multi-slider">
	<ul class="slides">
		<?php 
		for ($i = 0; $i < 6; $i++) {
		?>
		<li class="slide"><img src="images/ph-medium.png" width="230" height="230" alt="Placeholder" /></li>
		<?php 
		}
		?>
	</ul>
	<div class="dir-nav"><span class="dir-link prev">&laquo;</span> <span class="dir-link next">&raquo;</span></div>
</div>
<!-- MULTI-SPECIALS SLIDER -->
<div id="multi-slider" class="multi-slider">
	<div class="multi-inner">
		<ul class="slides">
			<?php 
			for ($i = 0; $i < 7; $i++) {
			?>
			<li class="slide"><img src="images/ph-medium.png" width="230" height="230" alt="Placeholder" /></li>
			<?php 
			}
			?>
		</ul>
	</div>
</div>
<!-- Equal Heights Code -->
<section class="eqh-wrap">
	<article class="eqh">Cras mattis consectetur purus sit amet fermentum. Maecenas faucibus mollis interdum.</article>
	<article class="eqh">Nullam id dolor id nibh ultricies vehicula ut id elit. Maecenas faucibus mollis interdum.</article>
	<article class="eqh">Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</article>
	<article class="eqh">Nulla vitae elit libero, a pharetra augue. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Cras mattis consectetur purus sit amet fermentum. Vestibulum id ligula porta felis euismod semper.</article>

	<article class="eqh">Nullam id dolor id nibh ultricies vehicula ut id elit. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Cras mattis consectetur purus sit amet fermentum. Sed posuere consectetur est at lobortis.</article>
	<article class="eqh">Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Maecenas sed diam eget risus varius blandit sit amet non magna. Donec id elit non mi porta gravida at eget metus.</article>
	<article class="eqh">Nulla vitae elit libero, a pharetra augue. Nullam quis risus eget urna mollis ornare vel eu leo.</article>
	<article class="eqh">Etiam porta sem malesuada magna mollis euismod. Donec ullamcorper nulla non metus auctor fringilla. Praesent commodo cursus magna, vel scelerisque nisl consectetur et.</article>
	<div class="clear"></div>
</section>
<!-- END .eqh-wrap -->
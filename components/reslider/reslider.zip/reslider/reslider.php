<!-- reSlider -->
<section id="slider1" class="reslider-wrap">
	<ul class="reslider">
		<li>
			<h2>This is Slide #1</h2>
		</li>
		<li>
			<h2>This is Slide #2</h2>
		</li>
		<li>
			<h2>This is Slide #3</h2>
		</li>
	</ul>
</section>
<!-- END reSlider -->

-----------------------------------------------
  Google Map Helper - READ ME
-----------------------------------------------

#1 - References
#2 - To Do
#3 - Overview

-----------------------------------------------
  #1 References
-----------------------------------------------

- API
  https://developers.google.com/maps/documentation/javascript/tutorial

- Code Samples (Change Marker)
  https://developers.google.com/maps/documentation/javascript/examples/marker-simple

-----------------------------------------------
  #2 To Do
-----------------------------------------------

- Don't remove initial icon.. change "B" for directions

-----------------------------------------------
  #3 Overview
-----------------------------------------------

- For Directions:
  + Needs an input field w/ ID of "saddr"
  + Needs a submit button w/ ID of "get-input"






